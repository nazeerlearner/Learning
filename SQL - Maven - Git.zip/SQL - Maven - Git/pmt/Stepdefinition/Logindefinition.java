package Stepdefinition;

import io.cucumber.java.en.Given;

public class Logindefinition {

	
	@Given ("^user is on login page$")
	public void user_is_on_login_page()
	{
		
	}
}
