package runner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

//(Ctrl+Shift+O is 'Organise Imports', and will add any missing imports, 
//remove any unused ones, and order all of your imports). The command is also found under Source > Organise Imports.

@RunWith(Cucumber.class)

@CucumberOptions(features = "featurefiles/OpenGoogle.feature", glue="Stepdefinition")
public class Runnerclass {

}
